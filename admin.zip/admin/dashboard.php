<!DOCTYPE html>
<html>
<head>
 <?php include('includes/head.php'); ?>
</head>
<body class="hold-transition skin-purple sidebar-mini">
<div class="wrapper" style="background:#ecf0f5">
<?php include('includes/header.php') ?>
<?php include('includes/left-sidebar.php'); ?> 
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper" style="min-height:615px !important;">
    <!-- Content Header (Page header) -->
    <section class="content-header" style="margin-top: 50px;">
      <h1>Control Panel</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>
  
    <!-- Main content -->
    <section class="content">
     <?php  
      if(isset($_GET['url'])){
        $url = explode('/',filter_var(rtrim($_GET['url'], '/'), FILTER_SANITIZE_URL));
        if($url[0] == 'dashboard'){
          require_once('pages/dashboard/dashboard.php');  
        }else if($url[0] == 'all-products'){
          require_once('pages/product/all-products.php');  
        }else if($url[0] == 'add-product'){
          require_once('pages/product/add-product.php');  
        }
        else if($url[0] == 'mailbox'){
          require_once('pages/mailbox/mailbox.html');  
        }else if($url[0] == 'compose-mail'){
          require_once('pages/mailbox/compose.html');  
        }else if($url[0] == 'read-mail'){
          require_once('pages/mailbox/read-mail.html');  
        }
      }else{
        require_once('pages/dashboard/dashboard.php');
      }
     ?>

    </section>
    <!-- /.content -->
<?php require_once('includes/footer.php'); ?>
