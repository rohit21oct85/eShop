 <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar" style="position: fixed;width:230px;background: #222d32;">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p>Alexander Pierce</p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
<!-- sidebar menu: : style can be found in sidebar.less -->
<ul class="sidebar-menu" data-widget="tree">
  <li class="header">MAIN NAVIGATION</li>
   <?php if(isset($_GET['url'])){
    $url = explode('/',filter_var(rtrim($_GET['url'], '/'), FILTER_SANITIZE_URL));
    
if($url[0] == 'add-product' || $url[0] == 'all-products'){
      $class_post="active";
}else if($url[0] == 'add-category'){
      $class_category="active";
}else if($url[0] == 'add-tags'){
      $class_tags="active";
}
/*else if($url[0] == 'mailbox' || $url[0] == 'compose-mail' || $url[0] == 'read-mail'|| $url[0] == 'sent-mail' || $url[0] == 'draft-mail' || $url[0] == 'trash-mail'){
      $class_mail="active";
    }*/
  } ?>

<!-- user -->
<li class="<?php echo $class_user ?>"><a href="?url=all-users"><i class="fa fa-circle-o"></i> <span>User Master</span> </a></li>
<!-- roles -->
<li class="<?php echo $class_role ?>"><a href="?url=all-roles"><i class="fa fa-circle-o"></i> <span>Role Master</span> </a></li>
<!-- permission -->
<li class="<?php echo $class_permission ?>"><a href="?url=all-permission"><i class="fa fa-circle-o"></i> <span>Permission Master</span> </a></li>
<!--  product -->
<li class="<?php echo $class_post ?>"><a href="?url=all-products"><i class="fa fa-circle-o"></i> <span>Product Master</span> </a></li>
<!--  product -->
<li class="<?php echo $class_order ?>"><a href="?url=all-orders"><i class="fa fa-circle-o"></i> <span>Order Master</span> </a></li>

<!-- category -->
<li class="<?php echo $class_category ?>"><a href="?url=add-category"><i class="fa fa-circle-o"></i> <span>Category Master</span> </a></li>
<!-- tags -->
<li class="<?php echo $class_tags ?>"><a href="?url=add-tags"><i class="fa fa-circle-o"></i> <span>Tag Master</span> </a></li>

<!-- tags -->
<li class="<?php echo $class_attributes ?>"><a href="?url=add-attributes"><i class="fa fa-circle-o"></i> <span>Attibutes Master</span> </a></li>

<!-- Email -->
<li class="treeview <?php echo $class_mail ?>" style="display: none;">
          <a href="javascript:void(0)">
            <i class="fa fa-envelope"></i> <span>Mailbox</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
                <li class="active"><a href="?url=mailbox"><i class="fa fa-inbox"></i> Inbox
                  <span class="label label-primary pull-right">12</span></a></li>
                <li><a href="?url=compose-mail"> <i class="fa fa-plus-circle"></i> Compose</a></li>
                <li><a href="?url=read-mail"><i class="fa fa-check-square-o"></i> Read</a></li>
                <li><a href="?url=sent-mail"><i class="fa fa-envelope-o"></i> Sent</a></li>
                <li><a href="?url=draft-mail"><i class="fa fa-file-text-o"></i> Drafts</a></li>
                <li><a href="?url=trash-mail"><i class="fa fa-trash-o"></i> Trash</a></li>
          </ul>
        </li>
</ul>
    </section>
    <!-- /.sidebar -->
  </aside>
