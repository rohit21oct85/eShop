<div class="banner1">
	<div class="container">
		<h3><a href="index.html">Home</a> / <span><?php echo ucfirst($_GET['url']) ?></span></h3>
	</div>
</div>
<!--banner-->