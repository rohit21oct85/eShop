<?php  
define('ABSPATH','http://127.0.0.1/eShop/');
?>