<?php  
require_once('core/init.php');
if(isset($_GET['url'])){
	require_once('includes/header_other.php');
}else{
	require_once('includes/header.php');
}
if(isset($_GET['url'])){
	$url = explode('/',filter_var(rtrim($_GET['url'], '/'), FILTER_SANITIZE_URL));
	if(file_exists('pages/'.$url[0].'.php')){
		$view = $url[0];
		require_once 'pages/'.$view.'.php';
	}	
}else{
	require_once('pages/home.php');
}
	
require_once('includes/footer.php');